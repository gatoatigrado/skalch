#!/usr/bin/env zsh

source ~/.zshrc.d/common.zsh

bindkey "\e[1;5C" forward-word   # ctrl cursor right
bindkey "\e[1;5D" backward-word  # ctrl cursor left

export PATH="$(pathunion "$PATH" ~/bin/all ~/sandbox/grgen/bin)"

function set_java1.7 { export JAVA_HOME=/usr/lib64/jvm/java-1.7.0; }

# opensuse
alias -- +='pushd .'; alias -- -='popd'
alias ..="cd .."; alias ...="cd ../.."; alias ....="cd ../../.."
# go last ls

alias dh="dolphin \$(pwd)"
alias kh="/usr/bin/konsole --workdir \$(pwd) && exit"
alias rs="hgstat; gitstat"

function 7zultra() {
    7z a -t7z -m0=lzma -mx=9 -mfb=64 -md=32m -ms=on "${1%/}.7z" "$1"
}
function 7zenc() {
    7z a -mx=0 -mhe=on -p "${1%/}.7z" "$1"
}
function invmv() {
    [ "$#" == 2 ] || { echo "two args only."; return 1; }
    mv "$2" "$1"
}
function kate_open() (
    for i in "$@"; do
        kate -u "$(find . -iname "$i" | head -n 1)"
    done
)
function make() (
    sed -i -r 's/^[ ]{8}([^ ])/\t\1/g' [mM]akefile
    /usr/bin/make "$@"
)
function ffvac() (
    for i in ~/.mozilla/firefox/*/*.sqlite*; do sqlite3 "$i" "VACUUM;"; done
)
function pykateall() (
    grep -l "${1:?usage: pykateall <search string>}" **/*.py | while read line; do
        echo "
$line"
        grep -n "$1" "$line"
        kate -u "$line" > /dev/null
    done
)
function td() {
    export TMPDIRNAME="$(date +"$HOME/temp/tmpfs/%s")"
    mkdir -p "$TMPDIRNAME"
    cd "$TMPDIRNAME"
}
function rtd() {
    rm -rf ${TMPDIRNAME:?this command removes a temporary directory created with \$(td)}
}

autoload -U colors && colors
PS1="%n@%m:%{$fg[blue]%}%~%{$reset_color%}> "
