#!/usr/bin/env zsh

function pathunion() (
    /usr/bin/python -c "import os, sys
paths = sys.argv[1].split(os.path.pathsep)
paths = [path for path in sys.argv[2:] if not path in paths] + paths
print(os.path.pathsep.join(paths))" "$@"
)
