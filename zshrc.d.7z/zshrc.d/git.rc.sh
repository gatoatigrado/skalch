#!/usr/bin/env zsh

function gitadddiff() {
    git add -u || return 1
    git add . || return 1
    git diff -M $(git log | head -n 1 | awk '{ print $2 }') "$@" > ~/temp/.temp.diff && \
        kwrite ~/temp/.temp.diff 2>/dev/null || return 1
    commitmessage=$(kdialog --inputbox "commit message or cancel" "[minor] ") || return 1
    [ "$commitmessage" ] && gitcommit -m "$commitmessage" "$@"
}
function gitrollback() {
    prev=$(git log --pretty=oneline -2 | tail -n 1 | cut -d' ' -f 1)
    git reset "$prev"
}
function gitcommit() {
    git commit "$@"
}
function gitincremental() {
    git commit -m -a "[incremental]" "$@"
}
git_repos=(
    ~/sandbox/skalch
    ~/sandbox/skalch_archetype/skalch-archetype
    ~/sandbox/cuda/pyptx
    )
function gitcmd() (
    iter=0
    for i in "${git_repos[@]}"; do
        iter=$((iter + 1))
        echo "=== $@ for '$i' \$(gitrepo ${iter}) ==="
        (cd "$i" && git "$@")
        echo
    done
)
function gitrepo() {
    cd "${git_repos[$1]}"
}
alias gitstat="gitcmd status"
alias gitpush="gitcmd push"
alias gitup="gitcmd pull"
