#!/usr/bin/env zsh

source ~/.zshrc.d/common.zsh

[ "${JAVA_HOME}" ] || { echo "set JAVA_HOME"; }
[ "${SCALA_HOME}" ] || { echo "set SCALA_HOME"; }
[ "${MAVEN_HOME}" ] || { echo "set MAVEN_HOME"; }
export CLASSPATH="$(pathunion "${CLASSPATH}" "$SCALA_HOME/lib/scala-library.jar" "$SCALA_HOME/lib/scala-compiler.jar")"
export PATH="$(pathunion "$PATH" "${JAVA_HOME}/bin" ~/bin/all "${SCALA_HOME}/bin" "${MAVEN_HOME}/bin")"
