#!/usr/bin/env zsh

# NOTE - consider using meld to view intra-line changes
function hgtocobol() {
    [ "$1" ] || { echo "usage - hgtocobol subpath"; return 1; }
    ssh_url="ssh://ntung@cobol.cs.berkeley.edu/repos/${1:?usage - hgtocobol subpath}"
    hg clone . "${ssh_url}"
    echo "[paths]
default = ${ssh_url}" >> .hg/hgrc
}
function hgfromcobol() {
    ssh_url="ssh://ntung@cobol.cs.berkeley.edu/repos/${1:?usage - hgfromcobol subpath [clone args]}"
    shift
    hg clone "${ssh_url}" "$@"
}
function hgadddiff() {
    [ -z "$(hg stat)" ] && return 0
    hg addremove || return 1
    hgdiff "$@" || return 1
    commitmessage=$(kdialog --inputbox "commit message or cancel" "[minor] ") || return 1
    [ "$commitmessage" ] && hg commit -m "$commitmessage" "$@"
}
function hgdiff() {
    hg diff "$@" > ~/temp/.temp.diff && \
        kwrite ~/temp/.temp.diff 2>/dev/null || return 1
}
function hgrecommit() {
    msg="$(hg log -r tip --template "{desc}")"
    hg rollback
    hg addremove
    hg commit -m "$msg"
}
# faster tab completion
alias hgcommit='hg commit "$@"'
function hgincremental() {
    hg commit -A -m "[incremental]"
}
mercurial_repos=(
    ~/sandbox/sketch-backend
    ~/sandbox/sketch-frontend
    ~/sandbox/ridgeweb
    ~/sandbox/learning/pysten
    ~/Documents/nm
    ~/Documents/research_other
    ~/sandbox/gatoatigrado_lib
    ~/bin
    ~/.zshrc.d
    )
function hgcmd() (
    iter=0
    for i in "${mercurial_repos[@]}"; do
        iter=$((iter + 1))
        echo "=== $@ for '$i' \$(hgrepo ${iter}) ==="
        (cd "$i" && hg "$@") || exit 1
        echo
    done
)
function hgrepo() {
    cd "${mercurial_repos[$1]}"
}
alias hgup="hgcmd pull -u"
alias hgstat="hgcmd stat"
alias hgpush="hgcmd push"
