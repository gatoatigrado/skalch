#!/usr/bin/env zsh

function ssh_server() {
    ssh_cmd="$1"
    shift
    if [ "$@" ]; then
        ssh "$ssh_cmd" "$@"
    else
        exec ssh "$ssh_cmd"
    fi
}

alias cobol="ssh_server ntung@cobol.cs.berkeley.edu"
alias ridge-inet="ssh_server 192.168.2.1"
alias ridge-web="ssh_server 192.168.2.3"
alias ridge-web-remote="ssh 24.130.87.154 -p 7223"
alias shoffner="ssh_server shoffner"
